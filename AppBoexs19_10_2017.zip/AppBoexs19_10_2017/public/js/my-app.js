
        var app = {
            user: null
        };


        // Bijhouden van de inloggegevens
        initApp = function() {
            firebase.auth().onAuthStateChanged(function(user) {
                if (user) {
                    // User is signed in.

                    var displayName = user.displayName;
                    var email = user.email;
                    var emailVerified = user.emailVerified;
                    var photoURL = user.photoURL;
                    var uid = user.uid;
                    var phoneNumber = user.phoneNumber;
                    var providerData = user.providerData;
                    user.getIdToken().then(function(accessToken) {
                        //document.getElementById('sign-in-status').textContent = 'Signed in';
                        //document.getElementById('sign-in').textContent = 'Sign out';
                        //document.getElementById('account-details').textContent = JSON.stringify({
                        //displayName: displayName,
                        //email: email,
                        //emailVerified: emailVerified,
                        //phoneNumber: phoneNumber,
                        //photoURL: photoURL,
                        //uid: uid,
                        //accessToken: accessToken,
                        //providerData: providerData
                    }, null, '  ');

                    app.user = user;


                } else {
                    // User is signed out.
                    //document.getElementById('sign-in-status').textContent = 'Signed out';
                    //document.getElementById('sign-in').textContent = 'Sign in';
                    //document.getElementById('account-details').textContent = 'null';
                }
            }, function(error) {
                console.log(error);
            });
        };

        window.addEventListener('load', function() {
            initApp()
        });


// Initialize your app
var myApp = new Framework7();

// Export selectors engine
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true
});

// Callbacks to run specific code for specific pages, for example for About page:
myApp.onPageInit('about', function (page) {
    // run createContentPage func after link was clicked
    $$('.create-page').on('click', function () {
        createContentPage();
    });
});

// Generate dynamic page
var dynamicPageIndex = 0;

function createContentPage() {
    mainView.router.loadContent(
        '<!-- Top Navbar-->' +
        '<div class="navbar">' +
        '  <div class="navbar-inner">' +
        '    <div class="left"><a href="#" class="back link"><i class="icon icon-back"></i><span>Back</span></a></div>' +
        '    <div class="center sliding">Dynamic Page ' + (++dynamicPageIndex) + '</div>' +
        '  </div>' +
        '</div>' +
        '<div class="pages">' +
        '  <!-- Page, data-page contains page name-->' +
        '  <div data-page="dynamic-pages" class="page">' +
        '    <!-- Scrollable page content-->' +
        '    <div class="page-content">' +
        '      <div class="content-block">' +
        '        <div class="content-block-inner">' +
        '          <p>Here is a dynamic page created on ' + new Date() + ' !</p>' +
        '          <p>Go <a href="#" class="back">back</a> or go to <a href="services.html">Services</a>.</p>' +
        '        </div>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>'
    );
    return;
}





// inloggen

$$('.login-screen .button').on('click', function () {
    var username = $$('.login-screen input[name = "username"]').val();
    var pwd = $$('.login-screen input[name = "password"]').val();

    // checken of juiste paswoord en username --> in de database nakijken kijken met een foreach in een list of array

    if (username == "" && pwd == "") {
        myApp.closeModal('.login-screen');
    }
});




// sluiten van registratie popup

$$('.registratie-popup .button').on('click', function () {

    myApp.closeModal('.login-screen');
    myApp.closeModal('.registratie-popup');

});


//Boek toevoegen aan interesse.

myApp.onPageInit('aankoop', function (page) {
    $$('.swipeout .likeP').on('click', function () {
        myApp.alert('Pagina is geliked en wordt toegevoegd aan je interesse.');
        console.log('click');
    });
});
